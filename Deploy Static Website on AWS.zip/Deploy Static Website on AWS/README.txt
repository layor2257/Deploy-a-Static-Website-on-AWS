Using the bucket website end point:

http://layorstatic2257bucket.s3-website-us-east-1.amazonaws.com


Website result using the Distribution domain name:

https://d2bsi81nksibhz.cloudfront.net


Using the bucket object:

https://layorstatic2257bucket.s3.amazonaws.com/index.html